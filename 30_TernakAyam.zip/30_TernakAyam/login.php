<?php
session_start();
require "koneksi.php";

$error = '';

if (isset($_SESSION['admin'])) {
    header('Location: admin/dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare(
        "SELECT id, username, password, nama
         FROM users
         WHERE username = ?
         LIMIT 1"
    );

    $stmt->bind_param("s", $username);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {

        $_SESSION['admin'] = $user['id'];
        $_SESSION['nama'] = $user['nama'];

        header('Location: admin/dashboard.php');
        exit;

    } else {
        $error = 'Username atau password salah.';
    }

    $stmt->close();
}
?>

<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Login Admin - Ternak Jaya</title>

    <link rel="stylesheet" href="style.css">
</head>

<body class="login-page">

    <div class="login-box">

        <h1>🐔 Ternak Jaya</h1>

        <p style="text-align:center;">
            Login Admin
        </p>

        <?php if ($error): ?>

            <div class="notice error">
                <?= htmlspecialchars($error) ?>
            </div>

        <?php endif; ?>

        <form method="post">

            <div class="field">

                <label>Username</label>

                <input
                    type="text"
                    name="username"
                    required
                >

            </div>

            <br>

            <div class="field">

                <label>Password</label>

                <input
                    type="password"
                    name="password"
                    required
                >

            </div>

            <br>

            <button
                type="submit"
                class="btn green"
                style="width:100%;"
            >
                Login
            </button>

        </form>

        <p style="text-align:center;">
            <a href="index.php">
                ← Kembali ke website
            </a>
        </p>

    </div>

</body>

</html>