<?php
require "koneksi.php";
require "partials_public.php";

$data = mysqli_query(
    $conn,
    "SELECT * FROM produk ORDER BY id DESC"
);

headerPublic('Produk Telur');
?>

<main class="container">

    <section class="section produk-section">

        <div class="section-title">
            <span class="produk-label">🥚 PRODUK TERNAK JAYA</span>

            <h2>Produk Telur</h2>

            <p>
                Telur segar dari Ternak Jaya untuk kebutuhan
                rumah tangga, warung, dan usaha.
            </p>
        </div>

        <div class="product-grid">

            <?php if (mysqli_num_rows($data) > 0): ?>

                <?php while ($row = mysqli_fetch_assoc($data)): ?>

                    <div class="product-card">

                        <div class="product-photo">

                            <?php if (!empty($row['foto'])): ?>

                                <img
                                    src="uploads/<?= htmlspecialchars($row['foto']); ?>"
                                    alt="<?= htmlspecialchars($row['nama_produk']); ?>"
                                >

                            <?php else: ?>

                                <div class="product-image">
                                    <span>🥚</span>
                                </div>

                            <?php endif; ?>

                        </div>

                        <div class="product-content">

                            <h3>
                                <?= htmlspecialchars($row['nama_produk']); ?>
                            </h3>

                            <p class="product-description">
                                <?= htmlspecialchars($row['deskripsi']); ?>
                            </p>

                            <div class="product-bottom">

                                <div class="product-price">
                                    Rp <?= number_format($row['harga'], 0, ',', '.'); ?>
                                    <span>
                                        / <?= htmlspecialchars($row['satuan']); ?>
                                    </span>
                                </div>

                                <span class="product-badge">
                                    Segar
                                </span>

                            </div>

                            <div class="product-info">
                                🥚 Telur segar dari Ternak Jaya
                            </div>

                        </div>

                    </div>

                <?php endwhile; ?>

            <?php else: ?>

                <div class="empty-data">

                    <div class="empty-icon">🥚</div>

                    <h3>Belum Ada Produk</h3>

                    <p>
                        Data produk telur belum ditambahkan.
                    </p>

                </div>

            <?php endif; ?>

        </div>

    </section>

</main>

<?php footerPublic(); ?>