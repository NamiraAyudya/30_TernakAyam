<?php
require "koneksi.php";

$username = "admin";
$password = password_hash("admin123", PASSWORD_DEFAULT);
$nama = "Administrator";

$cek = $conn->query("SELECT id FROM users WHERE username='admin'");
if ($cek && $cek->num_rows > 0) {
    echo "<h2>Admin sudah ada.</h2><p>Username: admin</p><p>Jika lupa password, hapus data admin dari tabel users lalu jalankan file ini lagi.</p>";
    exit;
}

$stmt = $conn->prepare("INSERT INTO users (username,password,nama,role) VALUES (?,?,?,'admin')");
$stmt->bind_param("sss", $username, $password, $nama);
$stmt->execute();

echo "<h2>Admin berhasil dibuat.</h2>";
echo "<p>Username: <b>admin</b></p><p>Password: <b>admin123</b></p>";
echo "<p>Silakan hapus file setup_admin.php setelah selesai.</p>";
?>
