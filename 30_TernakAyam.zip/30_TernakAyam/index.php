<?php 
require "koneksi.php"; 
require "partials_public.php";

$ayam = $conn->query(
    "SELECT COALESCE(SUM(jumlah),0) n 
     FROM ayam"
)->fetch_assoc()['n'];

$prod = $conn->query(
    "SELECT COALESCE(SUM(jumlah_telur),0) n 
     FROM produksi_telur 
     WHERE tanggal = CURDATE()"
)->fetch_assoc()['n'];

$stok = $conn->query(
    "SELECT COALESCE(SUM(masuk - terjual - rusak),0) n 
     FROM stok_telur"
)->fetch_assoc()['n'];

headerPublic('Beranda'); 
?>

<main class="container">

    <section class="hero">
        <div>
            <h1>Telur Segar Setiap Hari</h1>

            <p>
                Kami menyediakan telur ayam berkualitas dari peternakan sendiri 
                dengan perawatan yang baik, pencatatan produksi yang teratur, 
                dan pelayanan yang mudah.
            </p>

            <a class="btn" href="produk.php">
                Lihat Produk →
            </a>
        </div>
    </section>


    <section class="section">

        <div class="cards">

            <div class="card stat">
                🐔 Total Ayam

                <strong>
                    <?= number_format($ayam) ?>
                </strong>

                ekor
            </div>


            <div class="card stat">
                🥚 Produksi Hari Ini

                <strong>
                    <?= number_format($prod) ?>
                </strong>

                butir
            </div>


            <div class="card stat">
                📦 Stok Telur

                <strong>
                    <?= number_format($stok) ?>
                </strong>

                butir
            </div>


            <div class="card stat">
                🌿 Perawatan

                <strong>
                    Rutin
                </strong>

                dan terkontrol
            </div>

        </div>

    </section>


    <section class="section">

        <h2>Kenapa Memilih Kami?</h2>

        <p class="muted">
            Mengutamakan kualitas telur dan pengelolaan peternakan yang teratur.
        </p>


        <div class="cards">

            <div class="card">

                <h3>🥚 Telur Berkualitas</h3>

                <p>
                    Telur dikumpulkan dan dipisahkan dengan pencatatan yang teratur.
                </p>

            </div>


            <div class="card">

                <h3>🐔 Ayam Terawat</h3>

                <p>
                    Ayam mendapat pakan dan perawatan secara rutin.
                </p>

            </div>


            <div class="card">

                <h3>📊 Data Terpantau</h3>

                <p>
                    Produksi, stok, dan penjualan dicatat agar mudah dipantau.
                </p>

            </div>


            <div class="card">

                <h3>📞 Mudah Dihubungi</h3>

                <p>
                    Konsumen dapat menghubungi peternakan untuk kebutuhan telur.
                </p>

            </div>

        </div>

    </section>

</main>


<?php 
footerPublic(); 
?>