CREATE DATABASE IF NOT EXISTS ternak_ayam CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ternak_ayam;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'admin'
);

CREATE TABLE ayam (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kandang VARCHAR(100) NOT NULL,
    jumlah_ayam INT NOT NULL DEFAULT 0,
    umur VARCHAR(50) NOT NULL,
    kondisi VARCHAR(100) NOT NULL,
    keterangan TEXT
);

CREATE TABLE produksi_telur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL,
    jumlah_telur INT NOT NULL DEFAULT 0,
    telur_baik INT NOT NULL DEFAULT 0,
    telur_rusak INT NOT NULL DEFAULT 0,
    keterangan TEXT
);

CREATE TABLE stok_telur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL,
    masuk INT NOT NULL DEFAULT 0,
    terjual INT NOT NULL DEFAULT 0,
    rusak INT NOT NULL DEFAULT 0,
    keterangan TEXT
);

CREATE TABLE penjualan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL,
    nama_pembeli VARCHAR(100) NOT NULL,
    jumlah_kg DECIMAL(10,2) NOT NULL DEFAULT 0,
    harga_per_kg DECIMAL(12,2) NOT NULL DEFAULT 0,
    total DECIMAL(12,2) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'Belum Lunas'
);

CREATE TABLE pakan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL,
    jenis_pakan VARCHAR(100) NOT NULL,
    stok_kg DECIMAL(10,2) NOT NULL DEFAULT 0,
    pemakaian_kg DECIMAL(10,2) NOT NULL DEFAULT 0,
    sisa_kg DECIMAL(10,2) NOT NULL DEFAULT 0
);

CREATE TABLE produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_produk VARCHAR(100) NOT NULL,
    harga DECIMAL(12,2) NOT NULL DEFAULT 0,
    satuan VARCHAR(30) NOT NULL DEFAULT 'kg',
    stok INT NOT NULL DEFAULT 0,
    deskripsi TEXT
);

INSERT INTO ayam (nama_kandang,jumlah_ayam,umur,kondisi,keterangan) VALUES
('Kandang A',500,'8 bulan','Sehat','Ayam aktif dan produksi normal'),
('Kandang B',400,'9 bulan','Sehat','Produksi stabil'),
('Kandang C',350,'7 bulan','Sehat','Perawatan rutin');

INSERT INTO produksi_telur (tanggal,jumlah_telur,telur_baik,telur_rusak,keterangan) VALUES
(CURDATE(),1080,1060,20,'Produksi normal');

INSERT INTO stok_telur (tanggal,masuk,terjual,rusak,keterangan) VALUES
(CURDATE(),1080,0,20,'Stok produksi hari ini');

INSERT INTO produk (nama_produk,harga,satuan,stok,deskripsi) VALUES
('Telur Ayam Segar',28000,'kg',3450,'Telur ayam petelur segar dan berkualitas.'),
('Telur Omega',32000,'kg',500,'Telur dengan kandungan nutrisi yang baik.');
