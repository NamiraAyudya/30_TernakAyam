WEBSITE TERNAK AYAM PETELUR - TERNAK JAYA
=============================================

TEKNOLOGI:
- PHP 8+
- MySQL
- HTML/CSS
- XAMPP

CARA MENJALANKAN:
1. Extract folder "ternak-ayam" ke C:\xampp\htdocs\
2. Jalankan Apache dan MySQL di XAMPP.
3. Buka http://localhost/phpmyadmin
4. Buat/import database dengan file database.sql
5. Buka http://localhost/ternak-ayam/setup_admin.php
6. Login admin:
   username: admin
   password: admin123
7. Setelah berhasil membuat admin, HAPUS file setup_admin.php.
8. Buka http://localhost/ternak-ayam/

CATATAN:
- Folder uploads harus bisa ditulis jika nanti digunakan untuk upload foto.
- Website ini dibuat sederhana agar mudah dipelajari dan dikembangkan untuk tugas sekolah.
