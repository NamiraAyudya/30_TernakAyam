<?php 
require "partials_public.php"; 
headerPublic('Kontak'); 
?>

<main class="container">

    <section class="section">

        <h2>Hubungi Kami</h2>

        <div class="product-grid">

            <div class="card">

                <h3>Informasi Kontak</h3>

                <p>📞 0813-9282-6889</p>
                <p>📧 ternakUnggul@email.com</p>
                <p>📍 Desa Tegalampel, Jawa Tengah</p>
                <p>🕘 Senin-Sabtu, 07.00-17.00</p>

            </div>

            <div class="form-card">

                <h3>Kirim Pesan</h3>

                <div class="field">
                    <label>Nama</label>
                    <input type="text">
                </div>

                <br>

                <div class="field">
                    <label>Email</label>
                    <input type="email">
                </div>

                <br>

                <div class="field">
                    <label>Pesan</label>
                    <textarea></textarea>
                </div>

                <br>

                <button 
                    class="btn green" 
                    type="button" 
                    onclick="alert('Pesan berhasil disiapkan. Hubungi peternakan melalui WhatsApp untuk respons langsung.')"
                >
                    Kirim Pesan
                </button>

            </div>

        </div>

    </section>

</main>

<?php 
footerPublic(); 
?>

