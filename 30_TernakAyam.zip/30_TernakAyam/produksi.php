<?php

require "koneksi.php";
require "partials_public.php";


$data = $conn->query(
    "SELECT *
     FROM produksi_telur
     ORDER BY tanggal DESC, id_produksi DESC
     LIMIT 20"
);


headerPublic('Produksi Telur');

?>


<main class="container">

    <section class="section">

        <h2>
            Produksi Telur
        </h2>


        <p class="muted">
            Ringkasan produksi telur peternakan.
        </p>


        <div class="table-wrap">

            <table class="table">

                <tr>

                    <th>
                        Tanggal
                    </th>

                    <th>
                        Jumlah
                    </th>

                    <th>
                        Telur Baik
                    </th>

                    <th>
                        Rusak
                    </th>

                    <th>
                        Keterangan
                    </th>

                </tr>


                <?php while ($r = $data->fetch_assoc()): ?>

                    <?php
                    $telurBaik =
                        (int) $r['jumlah_telur']
                        - (int) $r['telur_rusak'];
                    ?>


                    <tr>

                        <td>
                            <?= htmlspecialchars(
                                $r['tanggal']
                            ) ?>
                        </td>


                        <td>
                            <?= number_format(
                                $r['jumlah_telur']
                            ) ?>
                            butir
                        </td>


                        <td>
                            <?= number_format(
                                $telurBaik
                            ) ?>
                            butir
                        </td>


                        <td>
                            <?= number_format(
                                $r['telur_rusak']
                            ) ?>
                            butir
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $r['keterangan']
                            ) ?>
                        </td>

                    </tr>


                <?php endwhile; ?>


            </table>

        </div>

    </section>

</main>


<?php

footerPublic();

?>