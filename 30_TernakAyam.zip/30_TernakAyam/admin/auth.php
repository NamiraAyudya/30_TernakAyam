<?php
session_start();
if(!isset($_SESSION['admin'])){header('Location: ../login.php');exit;}
require_once __DIR__.'/../koneksi.php';
?>