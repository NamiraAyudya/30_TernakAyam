<?php

$title = 'Dashboard';

require 'header.php';


$ayam = $conn->query(
    "SELECT COALESCE(SUM(jumlah),0) n
     FROM ayam"
)->fetch_assoc()['n'];


$prod = $conn->query(
    "SELECT COALESCE(SUM(jumlah_telur),0) n
     FROM produksi_telur
     WHERE tanggal = CURDATE()"
)->fetch_assoc()['n'];


$stok = $conn->query(
    "SELECT COALESCE(
        SUM(masuk - terjual - rusak),
        0
    ) n
    FROM stok_telur"
)->fetch_assoc()['n'];


$jual = $conn->query(
    "SELECT COALESCE(SUM(total),0) n
     FROM penjualan
     WHERE MONTH(tanggal) = MONTH(CURDATE())
     AND YEAR(tanggal) = YEAR(CURDATE())"
)->fetch_assoc()['n'];


$recent = $conn->query(
    "SELECT *
     FROM penjualan
     ORDER BY tanggal DESC, id DESC
     LIMIT 5"
);

?>


<div class="admin-head">

    <div>

        <h1>
            Dashboard
        </h1>

        <p>
            Selamat datang,
            <?= htmlspecialchars($_SESSION['nama']) ?> 👋
        </p>

    </div>

</div>


<div class="dashboard-cards">


    <div class="admin-card">

        🐔 Total Ayam

        <div class="number">
            <?= number_format($ayam) ?>
        </div>

        ekor

    </div>


    <div class="admin-card">

        🥚 Produksi Hari Ini

        <div class="number">
            <?= number_format($prod) ?>
        </div>

        butir

    </div>


    <div class="admin-card">

        📦 Stok Telur

        <div class="number">
            <?= number_format($stok) ?>
        </div>

        butir

    </div>


    <div class="admin-card">

        💰 Penjualan Bulan Ini

        <div class="number">
            Rp <?= number_format(
                $jual,
                0,
                ',',
                '.'
            ) ?>
        </div>

    </div>


</div>


<div class="panel">

    <h2>
        Penjualan Terbaru
    </h2>


    <div class="table-wrap">

        <table class="table">

            <tr>

                <th>
                    Tanggal
                </th>

                <th>
                    Pembeli
                </th>

                <th>
                    Jumlah
                </th>

                <th>
                    Harga
                </th>

                <th>
                    Total
                </th>

            </tr>


            <?php
            while ($r = $recent->fetch_assoc()):
            ?>

                <tr>

                    <td>
                        <?= htmlspecialchars(
                            $r['tanggal']
                        ) ?>
                    </td>


                    <td>
                        <?= htmlspecialchars(
                            $r['pembeli']
                        ) ?>
                    </td>


                    <td>
                        <?= number_format(
                            $r['jumlah']
                        ) ?>
                        butir
                    </td>


                    <td>
                        Rp
                        <?= number_format(
                            $r['harga'],
                            0,
                            ',',
                            '.'
                        ) ?>
                    </td>


                    <td>
                        Rp
                        <?= number_format(
                            $r['total'],
                            0,
                            ',',
                            '.'
                        ) ?>
                    </td>

                </tr>


            <?php
            endwhile;
            ?>


        </table>

    </div>

</div>


<?php

require 'footer.php';

?>