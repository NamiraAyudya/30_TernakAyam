<?php

$title = 'Laporan';

require 'header.php';


/* =========================
   LAPORAN PRODUKSI
   ========================= */

$produksi = $conn->query(
    "SELECT
        COUNT(*) AS hari,
        COALESCE(SUM(jumlah_telur), 0) AS total,
        COALESCE(SUM(telur_rusak), 0) AS rusak
     FROM produksi_telur"
)->fetch_assoc();


/* =========================
   HITUNG TELUR BAIK
   ========================= */

$produksi['baik'] =
    $produksi['total']
    - $produksi['rusak'];


/* =========================
   LAPORAN PENJUALAN
   ========================= */

$penjualan = $conn->query(
    "SELECT
        COUNT(*) AS transaksi,
        COALESCE(SUM(jumlah), 0) AS butir,
        COALESCE(SUM(total), 0) AS total
     FROM penjualan"
)->fetch_assoc();

?>


<div class="admin-head">

    <h1>
        Laporan Peternakan
    </h1>


    <button
        class="btn"
        onclick="window.print()"
    >
        🖨 Cetak
    </button>

</div>


<div class="dashboard-cards">


    <div class="admin-card">

        Hari Produksi

        <div class="number">
            <?= $produksi['hari'] ?>
        </div>

    </div>


    <div class="admin-card">

        Total Telur

        <div class="number">
            <?= number_format(
                $produksi['total']
            ) ?>
        </div>

        butir

    </div>


    <div class="admin-card">

        Telur Baik

        <div class="number">
            <?= number_format(
                $produksi['baik']
            ) ?>
        </div>

        butir

    </div>


    <div class="admin-card">

        Telur Rusak

        <div class="number">
            <?= number_format(
                $produksi['rusak']
            ) ?>
        </div>

        butir

    </div>


</div>


<div class="panel">

    <h2>
        Ringkasan Penjualan
    </h2>


    <p>

        Total transaksi:

        <b>
            <?= $penjualan['transaksi'] ?>
        </b>

    </p>


    <p>

        Total telur terjual:

        <b>
            <?= number_format(
                $penjualan['butir']
            ) ?>
            butir
        </b>

    </p>


    <p>

        Total penjualan:

        <b>
            Rp
            <?= number_format(
                $penjualan['total'],
                0,
                ',',
                '.'
            ) ?>
        </b>

    </p>


</div>


<?php

require 'footer.php';

?>