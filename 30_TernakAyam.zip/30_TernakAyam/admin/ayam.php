<?php
$title = 'Data Ayam';
require 'header.php';


/* =========================
   HAPUS DATA
========================= */

if (isset($_GET['hapus'])) {

    $id = (int) $_GET['hapus'];

    $conn->query(
        "DELETE FROM ayam 
         WHERE id = $id"
    );

    header('Location: ayam.php');
    exit;
}


/* =========================
   SIMPAN / UPDATE DATA
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = (int) ($_POST['id'] ?? 0);

    $kode = $conn->real_escape_string(
        $_POST['kode_ayam']
    );

    $jumlah = (int) $_POST['jumlah'];

    $tanggal = $conn->real_escape_string(
        $_POST['tanggal_masuk']
    );

    $keterangan = $conn->real_escape_string(
        $_POST['keterangan']
    );


    /* UPDATE */

    if ($id) {

        $conn->query(
            "UPDATE ayam SET
                kode_ayam = '$kode',
                jumlah = $jumlah,
                tanggal_masuk = '$tanggal',
                keterangan = '$keterangan'
             WHERE id = $id"
        );


    /* TAMBAH */

    } else {

        $conn->query(
            "INSERT INTO ayam (
                kode_ayam,
                jumlah,
                tanggal_masuk,
                keterangan
            )
            VALUES (
                '$kode',
                $jumlah,
                '$tanggal',
                '$keterangan'
            )"
        );
    }

    header('Location: ayam.php');
    exit;
}


/* =========================
   DATA UNTUK EDIT
========================= */

$edit = null;

if (isset($_GET['edit'])) {

    $id = (int) $_GET['edit'];

    $edit = $conn->query(
        "SELECT *
         FROM ayam
         WHERE id = $id"
    )->fetch_assoc();
}


/* =========================
   TAMPILKAN DATA
========================= */

$data = $conn->query(
    "SELECT *
     FROM ayam
     ORDER BY id DESC"
);
?>


<div class="admin-head">

    <h1>
        Data Ayam
    </h1>

</div>


<div class="form-card">

    <h3>
        <?= $edit ? 'Edit' : 'Tambah' ?> Data Ayam
    </h3>


    <form method="post">

        <input
            type="hidden"
            name="id"
            value="<?= $edit['id'] ?? 0 ?>"
        >


        <div class="form-grid">


            <div class="field">

                <label>
                    Kode Ayam
                </label>

                <input
                    name="kode_ayam"
                    required
                    value="<?= htmlspecialchars(
                        $edit['kode_ayam'] ?? ''
                    ) ?>"
                    placeholder="Contoh: AY001"
                >

            </div>


            <div class="field">

                <label>
                    Jumlah Ayam
                </label>

                <input
                    type="number"
                    name="jumlah"
                    min="0"
                    required
                    value="<?= $edit['jumlah'] ?? 0 ?>"
                >

            </div>


            <div class="field">

                <label>
                    Tanggal Masuk
                </label>

                <input
                    type="date"
                    name="tanggal_masuk"
                    required
                    value="<?= $edit['tanggal_masuk'] ?? date('Y-m-d') ?>"
                >

            </div>


            <div class="field full">

                <label>
                    Keterangan
                </label>

                <textarea
                    name="keterangan"
                ><?= htmlspecialchars(
                    $edit['keterangan'] ?? ''
                ) ?></textarea>

            </div>


        </div>


        <br>


        <button
            type="submit"
            class="btn green"
        >
            Simpan
        </button>


    </form>

</div>


<div class="panel">

    <div class="table-wrap">

        <table class="table">


            <tr>

                <th>
                    Kode Ayam
                </th>

                <th>
                    Jumlah
                </th>

                <th>
                    Tanggal Masuk
                </th>

                <th>
                    Keterangan
                </th>

                <th>
                    Aksi
                </th>

            </tr>


            <?php while ($r = $data->fetch_assoc()): ?>


                <tr>


                    <td>
                        <?= htmlspecialchars(
                            $r['kode_ayam']
                        ) ?>
                    </td>


                    <td>
                        <?= number_format(
                            $r['jumlah']
                        ) ?>
                        ekor
                    </td>


                    <td>
                        <?= htmlspecialchars(
                            $r['tanggal_masuk']
                        ) ?>
                    </td>


                    <td>
                        <?= htmlspecialchars(
                            $r['keterangan']
                        ) ?>
                    </td>


                    <td>

                        <a
                            class="btn"
                            href="?edit=<?= $r['id'] ?>"
                        >
                            Edit
                        </a>


                        <a
                            class="btn red"
                            href="?hapus=<?= $r['id'] ?>"
                            onclick="return confirm('Hapus data ayam?')"
                        >
                            Hapus
                        </a>

                    </td>


                </tr>


            <?php endwhile; ?>


        </table>

    </div>

</div>


<?php
require 'footer.php';
?>