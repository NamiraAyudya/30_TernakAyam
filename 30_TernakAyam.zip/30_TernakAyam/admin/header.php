<?php 

require_once __DIR__ . '/auth.php'; 

?>

<!doctype html>

<html lang="id">

<head>

    <meta charset="utf-8">

    <meta 
        name="viewport" 
        content="width=device-width,initial-scale=1"
    >

    <title>
        <?=htmlspecialchars($title ?? 'Admin')?> - Ternak Jaya
    </title>

    <link 
        rel="stylesheet" 
        href="../style.css"
    >

</head>

<body>

<div class="admin-layout">

    <aside class="sidebar">

        <div class="side-brand">

            🐔 Ternak Jaya

            <br>

            <small>
                Admin Panel
            </small>

        </div>

        <nav class="side-menu">

            <a href="dashboard.php">
                🏠 Dashboard
            </a>

            <a href="ayam.php">
                🐔 Data Ayam
            </a>

            <a href="produksi.php">
                🥚 Produksi Telur
            </a>

            <a href="stok.php">
                📦 Stok Telur
            </a>

            <a href="penjualan.php">
                🛒 Penjualan
            </a>

            <a href="produk.php">
                🥚 Produk
            </a>

            <a href="laporan.php">
                📊 Laporan
            </a>

            <a href="../index.php">
                🌐 Lihat Website
            </a>

            <a href="../logout.php">
                🚪 Logout
            </a>

        </nav>

    </aside>

    <main class="admin-main">