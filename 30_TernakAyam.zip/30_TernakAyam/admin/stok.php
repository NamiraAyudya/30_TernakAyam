<?php

$title = 'Stok Telur';

require 'header.php';


/* =========================
   HAPUS DATA STOK
========================= */

if (isset($_GET['hapus'])) {

    $id = (int) $_GET['hapus'];

    $conn->query(
        "DELETE FROM stok_telur WHERE id = $id"
    );

    header('Location: stok.php');

    exit;
}


/* =========================
   TAMBAH STOK
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $t = $_POST['tanggal'];

    $m = (int) $_POST['masuk'];

    $r = (int) $_POST['rusak'];

    $k = $conn->real_escape_string(
        $_POST['keterangan']
    );


    $conn->query(
        "INSERT INTO stok_telur (
            tanggal,
            masuk,
            terjual,
            rusak,
            keterangan
        )
        VALUES (
            '$t',
            $m,
            0,
            $r,
            '$k'
        )"
    );


    header('Location: stok.php');

    exit;
}


/* =========================
   AMBIL DATA STOK
========================= */

$data = $conn->query(
    "SELECT *
     FROM stok_telur
     ORDER BY tanggal DESC, id DESC"
);


/* =========================
   HITUNG STOK SAAT INI
========================= */

$total = $conn->query(
    "SELECT COALESCE(
        SUM(masuk - terjual - rusak),
        0
    ) AS n
    FROM stok_telur"
)->fetch_assoc()['n'];

?>

<div class="admin-head">

    <h1>
        Stok Telur
    </h1>

    <div class="admin-card">

        Stok saat ini:

        <b>
            <?= number_format($total) ?> butir
        </b>

    </div>

</div>


<!-- =========================
     FORM TAMBAH STOK
========================= -->

<div class="form-card">

    <h3>
        Tambah Stok
    </h3>


    <form method="post">

        <div class="form-grid">


            <div class="field">

                <label>
                    Tanggal
                </label>

                <input
                    type="date"
                    name="tanggal"
                    value="<?= date('Y-m-d') ?>"
                    required
                >

            </div>


            <div class="field">

                <label>
                    Telur Masuk (butir)
                </label>

                <input
                    type="number"
                    name="masuk"
                    value="0"
                    min="0"
                    required
                >

            </div>


            <div class="field">

                <label>
                    Telur Rusak (butir)
                </label>

                <input
                    type="number"
                    name="rusak"
                    value="0"
                    min="0"
                >

            </div>


            <div class="field full">

                <label>
                    Keterangan
                </label>

                <textarea
                    name="keterangan"
                ></textarea>

            </div>

        </div>


        <br>


        <button
            type="submit"
            class="btn green"
        >
            Simpan
        </button>

    </form>

</div>


<!-- =========================
     TABEL STOK
========================= -->

<div class="panel">

    <div class="table-wrap">

        <table class="table">

            <tr>

                <th>
                    Tanggal
                </th>

                <th>
                    Masuk
                </th>

                <th>
                    Terjual
                </th>

                <th>
                    Rusak
                </th>

                <th>
                    Sisa
                </th>

                <th>
                    Aksi
                </th>

            </tr>


            <?php
            while ($r = $data->fetch_assoc()):
            ?>

                <tr>

                    <td>
                        <?= htmlspecialchars($r['tanggal']) ?>
                    </td>


                    <td>
                        <?= number_format($r['masuk']) ?>
                        butir
                    </td>


                    <td>
                        <?= number_format($r['terjual']) ?>
                        butir
                    </td>


                    <td>
                        <?= number_format($r['rusak']) ?>
                        butir
                    </td>


                    <td>
                        <?= number_format(
                            $r['masuk']
                            - $r['terjual']
                            - $r['rusak']
                        ) ?>
                        butir
                    </td>


                    <td>

                        <a
                            class="btn red"
                            href="?hapus=<?= $r['id'] ?>"
                            onclick="return confirm('Hapus data stok ini?')"
                        >
                            Hapus
                        </a>

                    </td>

                </tr>


            <?php
            endwhile;
            ?>

        </table>

    </div>

</div>


<?php

require 'footer.php';

?>