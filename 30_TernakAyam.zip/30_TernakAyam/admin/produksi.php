<?php

$title = 'Produksi Telur';

require 'header.php';


/* =========================
   HAPUS DATA
   ========================= */

if (isset($_GET['hapus'])) {

    $id = (int) $_GET['hapus'];

    $conn->query(
        "DELETE FROM produksi_telur
         WHERE id_produksi = $id"
    );

    header('Location: produksi.php');
    exit;
}


/* =========================
   TAMBAH DATA
   ========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $tanggal = $_POST['tanggal'];

    $jumlah = (int) $_POST['jumlah_telur'];

    $rusak = (int) $_POST['telur_rusak'];

    $keterangan = $conn->real_escape_string(
        $_POST['keterangan']
    );


    $conn->query(
        "INSERT INTO produksi_telur (
            tanggal,
            jumlah_telur,
            satuan,
            telur_rusak,
            keterangan
        )
        VALUES (
            '$tanggal',
            $jumlah,
            'butir',
            $rusak,
            '$keterangan'
        )"
    );


    header('Location: produksi.php');
    exit;
}


/* =========================
   DATA PRODUKSI
   ========================= */

$data = $conn->query(
    "SELECT *
     FROM produksi_telur
     ORDER BY tanggal DESC"
);


/* =========================
   TOTAL PRODUKSI
   ========================= */

$total = $conn->query(
    "SELECT COALESCE(
        SUM(jumlah_telur),
        0
    ) AS total
    FROM produksi_telur"
)->fetch_assoc()['total'];

?>


<div class="admin-head">

    <h1>
        Produksi Telur
    </h1>

    <div class="admin-card">

        Total Produksi:
        <b>
            <?= number_format($total) ?> butir
        </b>

    </div>

</div>


<div class="form-card">

    <h3>
        Tambah Produksi
    </h3>


    <form method="post">

        <div class="form-grid">


            <div class="field">

                <label>
                    Tanggal
                </label>

                <input
                    type="date"
                    name="tanggal"
                    value="<?= date('Y-m-d') ?>"
                    required
                >

            </div>


            <div class="field">

                <label>
                    Jumlah Telur (butir)
                </label>

                <input
                    type="number"
                    name="jumlah_telur"
                    min="0"
                    step="1"
                    required
                >

            </div>


            <div class="field">

                <label>
                    Telur Rusak (butir)
                </label>

                <input
                    type="number"
                    name="telur_rusak"
                    value="0"
                    min="0"
                    step="1"
                >

            </div>


            <div class="field full">

                <label>
                    Keterangan
                </label>

                <textarea
                    name="keterangan"
                ></textarea>

            </div>


        </div>


        <br>


        <button
            type="submit"
            class="btn green"
        >
            Simpan
        </button>

    </form>

</div>


<div class="panel">

    <div class="table-wrap">

        <table class="table">

            <tr>

                <th>
                    Tanggal
                </th>

                <th>
                    Produksi
                </th>

                <th>
                    Rusak
                </th>

                <th>
                    Bersih
                </th>

                <th>
                    Keterangan
                </th>

                <th>
                    Aksi
                </th>

            </tr>


            <?php
            while ($r = $data->fetch_assoc()):
            ?>

                <tr>

                    <td>
                        <?= htmlspecialchars($r['tanggal']) ?>
                    </td>


                    <td>
                        <?= number_format(
                            $r['jumlah_telur']
                        ) ?>
                        butir
                    </td>


                    <td>
                        <?= number_format(
                            $r['telur_rusak']
                        ) ?>
                        butir
                    </td>


                    <td>
                        <?= number_format(
                            $r['jumlah_telur']
                            - $r['telur_rusak']
                        ) ?>
                        butir
                    </td>


                    <td>
                        <?= htmlspecialchars(
                            $r['keterangan']
                        ) ?>
                    </td>


                    <td>

                        <a
                            class="btn red"
                            href="?hapus=<?= $r['id_produksi'] ?>"
                            onclick="return confirm('Hapus data produksi ini?')"
                        >
                            Hapus
                        </a>

                    </td>

                </tr>

            <?php
            endwhile;
            ?>


        </table>

    </div>

</div>


<?php

require 'footer.php';

?>