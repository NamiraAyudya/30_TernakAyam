<?php

$title = 'Penjualan';

require 'header.php';


/* =========================
   HAPUS PENJUALAN
   ========================= */

if (isset($_GET['hapus'])) {

    $id = (int) $_GET['hapus'];

    $jual = $conn->query(
        "SELECT jumlah
         FROM penjualan
         WHERE id = $id"
    )->fetch_assoc();

    if ($jual) {

        $jumlah = (int) $jual['jumlah'];

        // Kembalikan stok yang sebelumnya terjual
        $sisa = $jumlah;

        $stok = $conn->query(
            "SELECT id, terjual
             FROM stok_telur
             WHERE terjual > 0
             ORDER BY tanggal DESC, id DESC"
        );

        while ($row = $stok->fetch_assoc()) {

            if ($sisa <= 0) {
                break;
            }

            $kembali = min(
                $sisa,
                (int) $row['terjual']
            );

            $conn->query(
                "UPDATE stok_telur
                 SET terjual = terjual - $kembali
                 WHERE id = " . (int) $row['id']
            );

            $sisa -= $kembali;
        }

        $conn->query(
            "DELETE FROM penjualan
             WHERE id = $id"
        );
    }

    header('Location: penjualan.php');
    exit;
}


/* =========================
   SIMPAN PENJUALAN
   ========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $t = $_POST['tanggal'];

    $pembeli = $conn->real_escape_string(
        $_POST['pembeli']
    );

    $jumlah = (int) $_POST['jumlah'];

    $harga = (float) $_POST['harga'];

    $total = $jumlah * $harga;


    /* =========================
       CEK STOK
       ========================= */

    $stok_result = $conn->query(
        "SELECT COALESCE(
            SUM(masuk - terjual - rusak),
            0
        ) AS stok
        FROM stok_telur"
    );

    $stok = (int) $stok_result
        ->fetch_assoc()['stok'];


    if ($jumlah <= 0) {

        echo "<script>
            alert('Jumlah telur harus lebih dari 0 butir.');
            history.back();
        </script>";

        exit;
    }


    if ($jumlah > $stok) {

        echo "<script>
            alert(
                'Stok telur tidak cukup. Stok tersedia: '
                + $stok
                + ' butir.'
            );
            history.back();
        </script>";

        exit;
    }


    /* =========================
       SIMPAN PENJUALAN
       ========================= */

    $simpan = $conn->query(
        "INSERT INTO penjualan (
            tanggal,
            pembeli,
            jumlah,
            harga,
            total
        )
        VALUES (
            '$t',
            '$pembeli',
            $jumlah,
            $harga,
            $total
        )"
    );


    if ($simpan) {

        /* =========================
           KURANGI STOK OTOMATIS
           ========================= */

        $sisa_jual = $jumlah;


        $stok_data = $conn->query(
            "SELECT id, masuk, terjual, rusak
             FROM stok_telur
             WHERE (masuk - terjual - rusak) > 0
             ORDER BY tanggal ASC, id ASC"
        );


        while ($row = $stok_data->fetch_assoc()) {

            if ($sisa_jual <= 0) {
                break;
            }


            $stok_baris =
                (int) $row['masuk']
                - (int) $row['terjual']
                - (int) $row['rusak'];


            $kurangi = min(
                $sisa_jual,
                $stok_baris
            );


            $conn->query(
                "UPDATE stok_telur
                 SET terjual = terjual + $kurangi
                 WHERE id = " . (int) $row['id']
            );


            $sisa_jual -= $kurangi;
        }
    }


    header('Location: penjualan.php');
    exit;
}


/* =========================
   DATA PENJUALAN
   ========================= */

$data = $conn->query(
    "SELECT *
     FROM penjualan
     ORDER BY tanggal DESC, id DESC"
);

?>


<div class="admin-head">

    <h1>
        Penjualan
    </h1>

</div>


<div class="form-card">

    <h3>
        Tambah Penjualan
    </h3>


    <form method="post">

        <div class="form-grid">


            <div class="field">

                <label>
                    Tanggal
                </label>

                <input
                    type="date"
                    name="tanggal"
                    value="<?= date('Y-m-d') ?>"
                    required
                >

            </div>


            <div class="field">

                <label>
                    Nama Pelanggan
                </label>

                <input
                    type="text"
                    name="pembeli"
                    required
                >

            </div>


            <div class="field">

                <label>
                    Jumlah (butir)
                </label>

                <input
                    type="number"
                    name="jumlah"
                    min="1"
                    step="1"
                    required
                >

            </div>


            <div class="field">

                <label>
                    Harga / Butir
                </label>

                <input
                    type="number"
                    name="harga"
                    min="0"
                    step="0.01"
                    required
                >

            </div>


        </div>


        <br>


        <button
            type="submit"
            class="btn green"
        >
            Simpan
        </button>

    </form>

</div>


<div class="panel">

    <div class="table-wrap">

        <table class="table">

            <tr>

                <th>
                    Tanggal
                </th>

                <th>
                    Pelanggan
                </th>

                <th>
                    Jumlah
                </th>

                <th>
                    Harga / Butir
                </th>

                <th>
                    Total
                </th>

                <th>
                    Aksi
                </th>

            </tr>


            <?php
            while ($r = $data->fetch_assoc()):
            ?>

                <tr>

                    <td>
                        <?= htmlspecialchars($r['tanggal']) ?>
                    </td>


                    <td>
                        <?= htmlspecialchars($r['pembeli']) ?>
                    </td>


                    <td>
                        <?= number_format($r['jumlah']) ?>
                        butir
                    </td>


                    <td>
                        Rp
                        <?= number_format(
                            $r['harga'],
                            0,
                            ',',
                            '.'
                        ) ?>
                    </td>


                    <td>
                        Rp
                        <?= number_format(
                            $r['total'],
                            0,
                            ',',
                            '.'
                        ) ?>
                    </td>


                    <td>

                        <a
                            class="btn red"
                            href="?hapus=<?= $r['id'] ?>"
                            onclick="return confirm('Hapus penjualan ini? Stok akan dikembalikan.')"
                        >
                            Hapus
                        </a>

                    </td>

                </tr>

            <?php
            endwhile;
            ?>

        </table>

    </div>

</div>


<?php

require 'footer.php';

?>