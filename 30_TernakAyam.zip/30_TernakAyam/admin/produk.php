<?php
$title = 'Produk';
require 'header.php';


/* =========================
   HAPUS PRODUK
========================= */

if (isset($_GET['hapus'])) {

    $id = (int) $_GET['hapus'];

    $conn->query(
        "DELETE FROM produk
         WHERE id = $id"
    );

    header('Location: produk.php');
    exit;
}


/* =========================
   TAMBAH / UPDATE PRODUK
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = (int) ($_POST['id'] ?? 0);

    $nama = $conn->real_escape_string(
        trim($_POST['nama_produk'] ?? '')
    );

    $harga = (float) ($_POST['harga'] ?? 0);

    $satuan = $conn->real_escape_string(
        trim($_POST['satuan'] ?? 'butir')
    );

    $deskripsi = $conn->real_escape_string(
        trim($_POST['deskripsi'] ?? '')
    );


    /* UPDATE */

    if ($id > 0) {

        $conn->query(
            "UPDATE produk SET
                nama_produk = '$nama',
                harga = $harga,
                satuan = '$satuan',
                deskripsi = '$deskripsi'
             WHERE id = $id"
        );

    }

    /* TAMBAH */

    else {

        $conn->query(
            "INSERT INTO produk (
                nama_produk,
                harga,
                satuan,
                deskripsi
            )
            VALUES (
                '$nama',
                $harga,
                '$satuan',
                '$deskripsi'
            )"
        );
    }

    header('Location: produk.php');
    exit;
}


/* =========================
   DATA UNTUK EDIT
========================= */

$edit = null;

if (isset($_GET['edit'])) {

    $id = (int) $_GET['edit'];

    $result = $conn->query(
        "SELECT *
         FROM produk
         WHERE id = $id
         LIMIT 1"
    );

    $edit = $result->fetch_assoc();
}


/* =========================
   DATA PRODUK
========================= */

$data = $conn->query(
    "SELECT *
     FROM produk
     ORDER BY id DESC"
);

?>


<div class="admin-head">

    <div>
        <h1>Produk Telur</h1>

        <p>
            Kelola produk telur Ternak Jaya.
        </p>
    </div>

</div>


<!-- =========================
     FORM PRODUK
========================= -->

<div class="panel">

    <h2>
        <?= $edit ? 'Edit Produk' : 'Tambah Produk' ?>
    </h2>

    <form method="post">

        <?php if ($edit): ?>

            <input
                type="hidden"
                name="id"
                value="<?= (int) $edit['id'] ?>"
            >

        <?php endif; ?>


        <div class="form-grid">

            <!-- NAMA -->

            <div class="field">

                <label>
                    Nama Produk
                </label>

                <input
                    type="text"
                    name="nama_produk"
                    value="<?= htmlspecialchars(
                        $edit['nama_produk'] ?? ''
                    ) ?>"
                    placeholder="Contoh: Telur Ayam Segar"
                    required
                >

            </div>


            <!-- HARGA -->

            <div class="field">

                <label>
                    Harga
                </label>

                <input
                    type="number"
                    name="harga"
                    value="<?= htmlspecialchars(
                        $edit['harga'] ?? ''
                    ) ?>"
                    placeholder="Contoh: 2000"
                    min="0"
                    required
                >

            </div>


            <!-- SATUAN -->

            <div class="field">

                <label>
                    Satuan
                </label>

                <select name="satuan">

                    <option
                        value="butir"
                        <?= (
                            ($edit['satuan'] ?? 'butir')
                            === 'butir'
                        ) ? 'selected' : '' ?>
                    >
                        butir
                    </option>

                    <option
                        value="kg"
                        <?= (
                            ($edit['satuan'] ?? '')
                            === 'kg'
                        ) ? 'selected' : '' ?>
                    >
                        kg
                    </option>

                    <option
                        value="pack"
                        <?= (
                            ($edit['satuan'] ?? '')
                            === 'pack'
                        ) ? 'selected' : '' ?>
                    >
                        pack
                    </option>

                </select>

            </div>


            <!-- DESKRIPSI -->

            <div class="field full">

                <label>
                    Deskripsi
                </label>

                <textarea
                    name="deskripsi"
                    placeholder="Deskripsi produk..."
                ><?= htmlspecialchars(
                    $edit['deskripsi'] ?? ''
                ) ?></textarea>

            </div>

        </div>


        <br>


        <div class="actions">

            <button
                type="submit"
                class="btn green"
            >
                <?= $edit ? 'Update Produk' : 'Simpan Produk' ?>
            </button>


            <?php if ($edit): ?>

                <a
                    href="produk.php"
                    class="btn"
                >
                    Batal
                </a>

            <?php endif; ?>

        </div>

    </form>

</div>


<!-- =========================
     DAFTAR PRODUK
========================= -->

<div class="panel">

    <h2>
        Daftar Produk
    </h2>

    <div class="table-wrap">

        <table class="table">

            <tr>

                <th>No</th>

                <th>Nama Produk</th>

                <th>Harga</th>

                <th>Satuan</th>

                <th>Deskripsi</th>

                <th>Aksi</th>

            </tr>


            <?php
            $no = 1;
            ?>

            <?php if ($data->num_rows > 0): ?>

                <?php while ($row = $data->fetch_assoc()): ?>

                    <tr>

                        <td>
                            <?= $no++ ?>
                        </td>


                        <td>

                            <strong>
                                <?= htmlspecialchars(
                                    $row['nama_produk']
                                ) ?>
                            </strong>

                        </td>


                        <td>

                            Rp
                            <?= number_format(
                                $row['harga'],
                                0,
                                ',',
                                '.'
                            ) ?>

                        </td>


                        <td>

                            <span class="badge">

                                <?= htmlspecialchars(
                                    $row['satuan']
                                ) ?>

                            </span>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $row['deskripsi']
                            ) ?>

                        </td>


                        <td>

                            <div class="actions">

                                <a
                                    href="produk.php?edit=<?= (int) $row['id'] ?>"
                                    class="btn"
                                >
                                    Edit
                                </a>


                                <a
                                    href="produk.php?hapus=<?= (int) $row['id'] ?>"
                                    class="btn red"
                                    onclick="return confirm('Yakin ingin menghapus produk ini?')"
                                >
                                    Hapus
                                </a>

                            </div>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td
                        colspan="6"
                        style="text-align:center;"
                    >
                        Belum ada produk.
                    </td>

                </tr>

            <?php endif; ?>

        </table>

    </div>

</div>


<?php
require 'footer.php';
?>