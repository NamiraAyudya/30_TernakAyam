<?php

require "partials_public.php";

headerPublic('Tentang Kami');
?>

<main class="container">

    <section class="section">

        <h2>Peternakan Ternak Ayam Unggul</h2>

        <p class="muted">
            Peternakan ayam petelur yang berfokus pada produksi telur
            segar dan berkualitas.
        </p>

        <div class="product-grid">

            <div class="card">

                <h3>Profil</h3>

                <p>
                    Ternak Ayam Unggul merupakan usaha peternakan ayam petelur
                    yang mengelola ayam, produksi telur, stok,
                    dan penjualan secara teratur.
                </p>

                <h3>Visi</h3>

                <p>
                    Menjadi peternakan telur yang terpercaya dan
                    menghasilkan produk berkualitas.
                </p>

                <h3>Misi</h3>

                <p>
                    Menjaga kesehatan ayam, kualitas telur, kebersihan
                    kandang, serta pelayanan kepada pelanggan.
                </p>

            </div>

            <div class="card">

                <h3>Informasi Pengelola</h3>

                <p>📍 Desa Tegalampel, Klaten, Jawa Tengah</p>

                <p>📞 0813-9282-6889</p>

                <p>🕘 Senin-Sabtu, 07.00-17.00</p>

            </div>

        </div>

    </section>

</main>

<?php

footerPublic();

?>