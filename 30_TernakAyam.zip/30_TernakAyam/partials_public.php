<?php

function headerPublic($title='Ternak Jaya'){
?>

<!doctype html>
<html lang="id">

<head>

    <meta charset="utf-8">

    <meta 
        name="viewport" 
        content="width=device-width,initial-scale=1"
    >

    <title>
        <?=htmlspecialchars($title)?> - Ternak Ayam Unggul
    </title>

    <link rel="stylesheet" href="style.css">

</head>

<body>

<header class="topbar">

    <a class="brand" href="index.php">
        🐔 Ternak Ayam Unggul
        <small>Peternakan Ayam Petelur</small>
    </a>

    <nav class="nav">

        <a href="index.php">
            Beranda
        </a>

        <a href="tentang.php">
            Tentang Kami
        </a>

        <a href="produk.php">
            Produk
        </a>

        <a href="produksi.php">
            Produksi
        </a>

        <a href="kontak.php">
            Kontak
        </a>

        <a class="btn green" href="login.php">
            Login
        </a>

    </nav>

</header>

<?php 
}

function footerPublic(){ 
?>

<footer class="footer">

    <h3>
        🐔 Ternak Ayam Unggul
    </h3>

    <p>
        Telur segar setiap hari dari peternakan ayam petelur.
    </p>

    <p>
        © <?=date('Y')?> Ternak Ayam Unggul
    </p>

</footer>

</body>
</html>

<?php 
} 
?>